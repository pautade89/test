---
name: test-scenario-design
description: Generate traceable, non-duplicated API test scenarios from approved business rules.
---

# Test Scenario Design Skill

Consider:
Functional, Boundary, Negative, Exceptional, Mandatory/Optional, Null/Blank, Invalid datatype/format, Min/Max, dependency failures, XML structure/schema, business-rule combinations, data consistency and regression.

Template:
| Scenario ID | Module | Requirement | Rule ID | Scenario | Type | Preconditions | Input Conditions | Expected Business Result | Expected API Behavior | Priority | Source |
|---|---|---|---|---|---|---|---|---|---|---|---|

Every scenario must test a distinguishable condition and trace to a rule/requirement. Do not invent expected behavior.
