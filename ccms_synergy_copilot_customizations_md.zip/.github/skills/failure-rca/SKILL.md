---
name: failure-rca
description: Evidence-based root cause analysis for XML API automation failures.
---

# Failure RCA Skill

Analyze in this order:
1. testcase metadata
2. environment/server
3. request XML
4. HTTP status
5. response XML
6. expected/actual diff
7. test data
8. business rule
9. logs
10. previous executions

Categories:
Automation defect, Test-data defect, Request defect, API defect, XML contract, Business-rule mismatch, Environment, UAT/load-balancing, Dependency, Unknown.

Confidence:
HIGH = directly supported
MEDIUM = strong evidence but confirmation missing
LOW = plausible hypothesis

Never convert a hypothesis into a confirmed defect without evidence.
