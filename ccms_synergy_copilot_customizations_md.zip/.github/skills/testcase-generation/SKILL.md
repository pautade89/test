---
name: testcase-generation
description: Convert approved API scenarios into executable-ready XML API test cases.
---

# Testcase Generation Skill

Template:
| Field | Value |
|---|---|
| TC ID | |
| Scenario ID | |
| JIRA ID | |
| Module | |
| API Name | |
| Test Case Name | |
| Test Type | |
| Priority | |
| Preconditions | |
| Test Data ID | |
| Request XML | |
| Dynamic Parameters | |
| Expected HTTP Status | |
| Expected Response XML | |
| Expected Business Result | |
| Validation Points | |
| Environment | |
| Server | |
| Automation Status | |
| Pytest Mapping | |
| Source Rule | |

Preserve XML namespace, root, required ordering, mandatory elements, attributes, datatypes and schema constraints. Do not fabricate XML or expected responses.
