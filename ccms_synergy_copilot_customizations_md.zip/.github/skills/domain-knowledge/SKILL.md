---
name: domain-knowledge
description: Extract and organize traceable common, CCMS and Synergy domain knowledge.
---

# Domain Knowledge Skill

Method:
1. Identify module and source.
2. Extract entities and relationships.
3. Extract rules.
4. Separate common/module-specific rules.
5. Extract conditions, transformations, validations and expected outputs.
6. Record provenance.
7. Identify conflicts and missing information.

Rule record:
rule_id, module, name, description, conditions, expected_behavior, source, source_type, version, status, confidence.

Approved rules are authoritative. Proposed rules require review. Inferences must not become confirmed rules. Preserve version/history and never mix CCMS/Synergy knowledge.
