---
name: synergy-domain-analysis
description: Analyze a Synergy requirement and extract traceable Synergy business knowledge.
agent: synergy-domain
---

Analyze the supplied Synergy requirement.

Return:
Requirement summary
Synergy entities
API/XML details
Confirmed rules with Rule ID and Source
Input conditions
Transformations
Validations
Positive conditions
Boundary conditions
Negative conditions
Exceptional conditions
Dependencies
Assumptions
Open questions

Separate COMMON and SYNERGY-SPECIFIC rules. Do not infer missing behavior.
