---
name: ccms-domain-analysis
description: Analyze a CCMS requirement and extract traceable CCMS business knowledge.
agent: ccms-domain
---

Analyze the supplied CCMS requirement.

Return:
Requirement summary
CCMS entities
API/XML details
Confirmed rules with Rule ID and Source
Input conditions
Transformations
Validations
Positive conditions
Boundary conditions
Negative conditions
Exceptional conditions
Dependencies
Assumptions
Open questions

Separate COMMON and CCMS-SPECIFIC rules. Do not infer missing behavior.
