---
name: ccms-test-scenario-generation
description: Generate a complete CCMS scenario matrix from approved rules.
agent: ccms-test-design
---

Generate CCMS test scenarios.

| Scenario ID | Requirement | Rule ID | Scenario | Type | Preconditions | Input Conditions | Expected Business Result | Expected API Behavior | Priority | Source |
|---|---|---|---|---|---|---|---|---|---|---|

Cover functional, boundary, negative, exceptional, XML/schema, validation, data-consistency, dependency and regression cases where applicable.

Do not generate detailed test cases yet. Mark ambiguous behavior NEEDS SME CONFIRMATION.
