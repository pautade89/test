---
name: ccms-testcase-generation
description: Generate detailed CCMS XML API test cases from approved scenarios.
agent: ccms-test-design
---

Convert approved CCMS scenarios into detailed cases.

| TC ID | Scenario ID | JIRA ID | Module | API | Test Case Name | Type | Priority | Preconditions | Test Data ID | Request XML | Dynamic Parameters | Expected HTTP Status | Expected Response XML | Expected Business Result | Validation Points | Environment | Server | Automation Status | Pytest Mapping | Source Rule |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

Do not change business intent or invent expected responses.
