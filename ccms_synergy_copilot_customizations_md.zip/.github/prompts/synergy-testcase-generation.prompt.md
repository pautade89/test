---
name: synergy-testcase-generation
description: Generate detailed Synergy XML API test cases from approved scenarios.
agent: synergy-test-design
---

Convert approved Synergy scenarios into detailed cases.

| TC ID | Scenario ID | JIRA ID | Module | API | Test Case Name | Type | Priority | Preconditions | Test Data ID | Request XML | Dynamic Parameters | Expected HTTP Status | Expected Response XML | Expected Business Result | Validation Points | Environment | Server | Automation Status | Pytest Mapping | Source Rule |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

Do not apply CCMS-specific rules or invent expected responses.
