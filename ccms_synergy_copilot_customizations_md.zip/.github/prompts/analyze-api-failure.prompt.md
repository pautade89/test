---
name: analyze-api-failure
description: Analyze a CCMS or Synergy Pytest XML API failure and produce evidence-based RCA.
agent: failure-rca
---

Analyze the supplied failure.

Identify:
Module, Environment, Server, API, Test case, HTTP status, Expected result, Actual result, XML differences, relevant business rule, test-data validity, environment indicators, failure category, likely root cause, confidence, alternative causes, evidence gaps, recommended investigation and suggested automation change.

Do not call a hypothesis a confirmed root cause.
