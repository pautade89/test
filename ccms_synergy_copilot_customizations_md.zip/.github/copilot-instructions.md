# CCMS + Synergy API Testing - Repository Instructions

This repository contains Python Pytest automation for XML POST APIs for CCMS and Synergy.

## Environment
DEV, QA, UAT, PROD. UAT may use UAT1 and UAT2 for load balancing.

## Rules
1. Never invent business rules.
2. Keep CCMS-specific and Synergy-specific rules separate.
3. Common rules may be used by both only when documented as common.
4. Prefer approved domain memory and repository evidence over generic knowledge.
5. Trace important rules to JIRA/specification/source.
6. Distinguish confirmed rules, assumptions, inferences and unknowns.
7. Do not automatically change production automation based only on AI inference.
8. XML must preserve namespaces, structure, required ordering and mandatory elements.
9. For failures distinguish application, automation, test-data, XML, business-rule, environment, configuration, dependency and load-balancing causes.

## Evidence precedence
Approved structured rules > approved module knowledge > current requirements/JIRA > XML/XSD docs > approved test cases > execution evidence > other docs > generic knowledge.

## Test lifecycle
Requirement -> Domain understanding -> Business rules -> Test scenarios -> Review -> Detailed test cases -> XML/test data -> Pytest -> Execution -> RCA.

## Required test-case information
TC ID, Scenario ID, JIRA ID, Module, API, name, type, priority, preconditions, test data, request XML, expected HTTP status, expected response XML, expected business result, validation points, environment/server, automation mapping.

Never present an inference as an approved banking rule.
