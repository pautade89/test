# CCMS + Synergy Copilot Customizations

This package contains separate CCMS and Synergy domain agents, separate test-design agents, a common RCA agent, reusable skills, and prompts.

Recommended flow:
Requirement -> Domain Agent -> Approved Rules -> Test Scenarios -> Review -> Test Cases -> Pytest -> Execution -> RCA.

Store actual banking/domain knowledge separately from these instruction files. A future MCP memory service can expose approved rules, entities, XML rules, scenarios and rule history to Copilot.
