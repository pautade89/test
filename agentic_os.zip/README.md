# Agentic OS

A local-first, multi-agent orchestration dashboard. Runs entirely on your own machine — no cloud backend, no telemetry. Talk to Claude, ChatGPT, Gemini, local Ollama models, or any custom OpenAI-compatible endpoint (OmniRoute / OpenRouter / vLLM / LM Studio) from one control room, with a shared local memory vault.

Built with Next.js 14 (App Router) + TypeScript.

---

## What's inside

- **Mission Control** — live status of every agent (online/offline, provider, model), heartbeat, host info.
- **Per-agent pages** with two modes:
  - **Chat** — streaming conversation, optional memory injection (RAG-lite from your vault).
  - **Goal Mode** — hand an agent a long-horizon goal; it runs a *bounded* autonomous loop (max 25 turns, abortable) and streams a live log. Each run is written back to memory.
- **Memory** — a searchable, Obsidian-compatible markdown vault rendered as a "galaxy" graph (notes = stars, `[[wikilinks]]` = threads, brighter = recently touched).
- **Settings** — add provider API keys; they're **encrypted at rest** and never returned to the browser.

---

## Quick start

Requires **Node.js 18.17+**.

```bash
# 1. Install
npm install

# 2. Generate your secrets
npm run keygen
#   → copy APP_SECRET and APP_TOKEN into a new .env file
cp .env.example .env      # then paste the two values in

# 3. Run (binds to 127.0.0.1 only)
npm run dev
```

Open http://127.0.0.1:3000, paste your `APP_TOKEN` to unlock, then add provider keys under **Settings**.

For local models, install [Ollama](https://ollama.com), then e.g. `ollama pull llama3.1`. No key needed.

For a **custom / OmniRoute** agent, set its base URL in `src/config/agents.ts` (the `omniroute` agent's `baseUrl`) and its key under Settings → Custom.

---

## Security model (local-only by design)

This app is meant to run on your machine and nowhere else. The defenses, in layers:

1. **Loopback bind.** `dev`/`start` bind to `127.0.0.1`, so the server is unreachable from your LAN or the internet. Nothing listens on a public interface.
2. **Rejects proxied requests.** The auth guard refuses any request carrying an `X-Forwarded-For` header or a non-loopback host — so accidentally putting it behind a tunnel/reverse proxy fails closed rather than exposing it.
3. **Token gate.** Every API call requires the `APP_TOKEN` bearer (constant-time compared). This stops other local users/processes from hitting the API. The token lives only in `sessionStorage` (cleared when the tab closes) — never `localStorage`, never logged.
4. **Keys encrypted at rest.** Provider API keys saved via the UI are AES-256-GCM encrypted with `APP_SECRET` in `data/keys.enc.json` (file mode `600`). The API only ever returns booleans ("key set / not set"), never the keys.
5. **Strict CSP + headers.** `connect-src 'self'`, `frame-ancestors 'none'`, `X-Frame-Options: DENY`, `nosniff`, `no-referrer`. Provider calls happen server-side, so the browser never holds a key.
6. **Bounded autonomy.** Goal Mode is capped at 25 turns, is abortable, and executes **no shell commands** — it only calls model APIs and writes markdown to the vault.
7. **Rate limiting.** Token-bucket limits on chat and goal launches guard against runaway loops.
8. **Input validation.** All API bodies are validated with Zod.

### Your responsibilities
- Keep `.env` and `data/keys.enc.json` out of version control (already git-ignored).
- Don't expose the port via a tunnel (ngrok/cloudflared) — that bypasses the loopback protection. If you must, add real auth in front.
- Back up the `data/vault/` folder; it's your memory.

---

## Architecture

```
src/
  app/
    page.tsx                 Mission Control
    agent/[id]/page.tsx      Chat + Goal Mode
    memory/page.tsx          Galaxy graph + search + add
    settings/page.tsx        Provider key management
    api/
      chat/route.ts          streaming chat (+ memory injection)
      goals/route.ts         launch / list goals
      goals/[id]/route.ts    poll live log / stop
      memory/route.ts        search / write notes
      memory/graph/route.ts  galaxy nodes + edges
      settings/route.ts      save keys / key status
      status/route.ts        agent + system health
  lib/
    agents/
      types.ts               Provider + AgentConfig interfaces
      anthropic.ts           Claude provider (+ shared SSE parser)
      openai-compatible.ts   OpenAI / Ollama / Custom (one adapter)
      gemini.ts              Gemini provider
      registry.ts            provider lookup + key resolution
      keystore.ts            encrypted key storage
      goals.ts               bounded autonomous goal engine
    memory/store.ts          markdown vault + search + graph
    security/
      crypto.ts              AES-256-GCM + constant-time compare
      auth.ts                loopback + token guard
      ratelimit.ts           token-bucket limiter
    client.ts                browser API helper (attaches token)
  config/agents.ts           the agent roster (edit to add agents)
data/vault/                  your Obsidian-compatible memory
```

### Adding an agent
Append to `AGENTS` in `src/config/agents.ts`: pick a `provider`, `model`, `color`, `systemPrompt`, and (for `custom`) a `baseUrl`. It appears in the sidebar and Mission Control automatically.

---

## Notes on the reference design
This is an original implementation inspired by the layout in the screenshots you shared (Mission Control, agent control rooms, Goal Mode, memory galaxy). The proprietary "Hermes/Omi" memory service from that build isn't a public package, so memory here is a self-contained local vault + graph you fully own. Everything is yours to modify.
